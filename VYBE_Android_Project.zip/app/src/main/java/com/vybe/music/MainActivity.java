package com.vybe.music;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.util.ArrayList;

public class MainActivity extends Activity {
    final int BG = Color.rgb(8,11,16), PANEL = Color.rgb(23,28,37), GREEN = Color.rgb(183,247,206), MUTED = Color.rgb(146,153,167), WHITE = Color.WHITE;
    LinearLayout root, library;
    EditText linkInput;
    TextView status;
    ArrayList<String> playlists = new ArrayList<>();

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(1, Color.rgb(40,46,58)); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    void gap(LinearLayout l, int h) { View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1,h)); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        root = vertical(); root.setPadding(22,18,22,24); root.setBackgroundColor(BG); scroll.addView(root);
        setContentView(scroll);
        LinearLayout brand = new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("V",24, BG, true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(GREEN,18)); brand.addView(logo,new LinearLayout.LayoutParams(52,52));
        LinearLayout names = vertical(); names.setPadding(12,0,0,0); names.addView(text("V Y B E",23,WHITE,true)); names.addView(text("YOUR MUSIC SPACE",10,MUTED,true)); brand.addView(names,new LinearLayout.LayoutParams(-2,-2)); root.addView(brand);
        gap(root,28);
        root.addView(text("Your sound.",30,WHITE,true)); root.addView(text("Your world.",30,GREEN,true));
        gap(root,6); root.addView(text("Bring your playlists together.",14,MUTED,false)); gap(root,24);
        LinearLayout panel = vertical(); panel.setPadding(16,16,16,16); panel.setBackground(shape(PANEL,22)); root.addView(panel);
        panel.addView(text("Import a Spotify playlist",18,WHITE,true)); gap(panel,6); panel.addView(text("Paste a public playlist link to add it to your library.",12,MUTED,false)); gap(panel,14);
        linkInput = new EditText(this); linkInput.setSingleLine(true); linkInput.setTextColor(WHITE); linkInput.setHintTextColor(MUTED); linkInput.setHint("https://open.spotify.com/playlist/…"); linkInput.setTextSize(13); linkInput.setPadding(12,12,12,12); linkInput.setBackground(shape(Color.rgb(17,22,31),14)); panel.addView(linkInput,new LinearLayout.LayoutParams(-1,-2));
        gap(panel,12);
        Button importButton = new Button(this); importButton.setText("＋  Import playlist"); importButton.setTextColor(BG); importButton.setAllCaps(false); importButton.setTypeface(Typeface.DEFAULT,Typeface.BOLD); importButton.setBackground(shape(GREEN,16)); panel.addView(importButton,new LinearLayout.LayoutParams(-1,54));
        gap(panel,10); status = text("Demo build: Spotify API connection is not configured yet.",12,MUTED,false); panel.addView(status);
        importButton.setOnClickListener(v -> addPlaylist());
        gap(root,26); root.addView(text("Made for you",20,WHITE,true)); gap(root,12);
        String[][] moods = {{"☾","Chill Tamil","Mellow moods"},{"ϟ","Mass Mode","High energy"},{"✦","Night Drive","After hours"},{"♡","Favourites","Your collection"}};
        int[] colors = {Color.rgb(40,92,80),Color.rgb(140,56,46),Color.rgb(57,62,133),Color.rgb(140,60,100)};
        for(int i=0;i<moods.length;i+=2) {
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for(int j=i;j<Math.min(i+2,moods.length);j++) {
                final String title=moods[j][1];
                LinearLayout tile=vertical(); tile.setPadding(13,13,13,13); tile.setBackground(shape(PANEL,18));
                TextView art=text(moods[j][0],28,WHITE,true); art.setGravity(Gravity.CENTER); art.setBackground(shape(colors[j],16)); tile.addView(art,new LinearLayout.LayoutParams(-1,82));
                gap(tile,10); tile.addView(text(title,15,WHITE,true)); gap(tile,4); tile.addView(text(moods[j][2],11,MUTED,false));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(0,0, j==i?10:0,0); row.addView(tile,lp);
            }
            root.addView(row); gap(root,10);
        }
        gap(root,16); root.addView(text("Your library",20,WHITE,true)); gap(root,10);
        library=vertical(); root.addView(library); showEmpty();
        gap(root,18);
        TextView footer=text("HOME       SEARCH       LIBRARY       LIKED",12,GREEN,true); footer.setGravity(Gravity.CENTER); root.addView(footer);
    }
    void showEmpty() {
        if(playlists.isEmpty()){ TextView empty=text("Your imported playlists will appear here.",13,MUTED,false); empty.setPadding(14,20,14,20); empty.setBackground(shape(PANEL,16)); library.addView(empty); }
    }
    void addPlaylist() {
        String link=linkInput.getText().toString().trim();
        if(!link.matches("https?://open\\.spotify\\.com/playlist/[A-Za-z0-9]+.*")) {
            status.setText("Paste a valid Spotify playlist URL."); status.setTextColor(Color.rgb(255,150,160)); return;
        }
        String id=link.replaceAll("^.*playlist/([A-Za-z0-9]+).*$","$1");
        playlists.add(id);
        library.removeAllViews();
        for(String pid:playlists) {
            LinearLayout item=new LinearLayout(this); item.setPadding(12,12,12,12); item.setGravity(Gravity.CENTER_VERTICAL); item.setBackground(shape(PANEL,16));
            TextView art=text("♫",25,GREEN,true); art.setGravity(Gravity.CENTER); art.setBackground(shape(Color.rgb(35,66,55),14)); item.addView(art,new LinearLayout.LayoutParams(54,54));
            LinearLayout info=vertical(); info.setPadding(12,0,0,0); info.addView(text("Spotify playlist",15,WHITE,true)); info.addView(text("Playlist ID: "+pid,11,MUTED,false)); item.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            TextView open=text("↗",20,GREEN,true); open.setPadding(10,10,10,10); item.addView(open);
            item.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/playlist/"+pid))));
            library.addView(item); gap(library,8);
        }
        status.setText("Playlist link added. Real track import needs Spotify API authorization."); status.setTextColor(GREEN);
    }
}
